var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/discord/check/route.js")
R.c("server/chunks/[root-of-the-server]__ff4cf2bf._.js")
R.c("server/chunks/node_modules_3fbac452._.js")
R.c("server/chunks/[root-of-the-server]__1db19fa0._.js")
R.c("server/chunks/[root-of-the-server]__db2b3a24._.js")
R.c("server/chunks/[root-of-the-server]__487939db._.js")
R.c("server/chunks/_next-internal_server_app_api_discord_check_route_actions_f7df5ae4.js")
R.m(48209)
module.exports=R.m(48209).exports

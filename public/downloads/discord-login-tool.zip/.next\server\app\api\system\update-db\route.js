var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/system/update-db/route.js")
R.c("server/chunks/[root-of-the-server]__021016e9._.js")
R.c("server/chunks/_a1e85dba._.js")
R.c("server/chunks/node_modules_c02e7353._.js")
R.c("server/chunks/[root-of-the-server]__db2b3a24._.js")
R.c("server/chunks/[root-of-the-server]__487939db._.js")
R.c("server/chunks/_next-internal_server_app_api_system_update-db_route_actions_00b93aaf.js")
R.m(72681)
module.exports=R.m(72681).exports

module.exports=[11640,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_discord_check_route_actions_f7df5ae4.js.map
var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/discord/login-headless/route.js")
R.c("server/chunks/[root-of-the-server]__c2a039a3._.js")
R.c("server/chunks/[root-of-the-server]__db2b3a24._.js")
R.c("server/chunks/[root-of-the-server]__17fe870c._.js")
R.c("server/chunks/_next-internal_server_app_api_discord_login-headless_route_actions_e44396d7.js")
R.m(42408)
module.exports=R.m(42408).exports

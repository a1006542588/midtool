var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/email/firstmail/route.js")
R.c("server/chunks/[root-of-the-server]__970701bc._.js")
R.c("server/chunks/[root-of-the-server]__068d2cbe._.js")
R.c("server/chunks/[root-of-the-server]__db2b3a24._.js")
R.c("server/chunks/_next-internal_server_app_api_email_firstmail_route_actions_3899cc8d.js")
R.m(62710)
module.exports=R.m(62710).exports

module.exports=[96562,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_tools_discord-login_page_actions_d5bca304.js.map
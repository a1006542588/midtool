module.exports=[36923,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_discord_login-headless_route_actions_e44396d7.js.map
module.exports=[51024,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_tools_list-cleaner_page_actions_f9ff27e7.js.map
module.exports=[36378,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_tools_cookie-converter_page_actions_d251a7d3.js.map
module.exports=[54479,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_tools_format-converter_page_actions_73b6a547.js.map
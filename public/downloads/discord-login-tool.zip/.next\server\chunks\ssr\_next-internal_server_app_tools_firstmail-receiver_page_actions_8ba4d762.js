module.exports=[89695,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_tools_firstmail-receiver_page_actions_8ba4d762.js.map
module.exports=[25935,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_tools_text-extractor_page_actions_64874e90.js.map
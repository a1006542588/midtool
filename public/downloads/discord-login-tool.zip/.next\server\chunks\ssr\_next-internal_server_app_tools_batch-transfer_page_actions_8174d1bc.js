module.exports=[13664,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_tools_batch-transfer_page_actions_8174d1bc.js.map
module.exports=[21269,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_tools_morelogin_page_actions_865b2cc3.js.map
module.exports=[85826,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_tools_wallet-generator_page_actions_5c92daf5.js.map
module.exports=[5755,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_tools_list-diff_page_actions_0d73e21f.js.map
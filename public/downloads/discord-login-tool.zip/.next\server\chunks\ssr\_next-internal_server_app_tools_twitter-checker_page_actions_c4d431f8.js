module.exports=[1006,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_tools_twitter-checker_page_actions_c4d431f8.js.map
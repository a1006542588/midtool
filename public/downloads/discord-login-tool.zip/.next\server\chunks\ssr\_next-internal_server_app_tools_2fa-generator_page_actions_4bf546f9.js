module.exports=[62340,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_tools_2fa-generator_page_actions_4bf546f9.js.map